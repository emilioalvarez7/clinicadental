=======================================================================
JCalendar - v1.1.4 - 07/17/02 - Readme File  - 
=======================================================================

(C)1998-2002 Kai Toedter
Released under GNU Lesser General Public License (see license.html)
kai@toedter.com
www.toedter.com

=======================================================================
THANKS

I would like to thank all the people who have sent e-mails and
provided bug fixes and suggestions.

=======================================================================
UPDATES

JCalendar is updated from time to time.
Check the web site to stay informed about the updates:
  http://www.toedter.com

=======================================================================
CONTENTS

At the top level you find the HTML documentation. Please read the file
index.html. This distribution contains several sub-directories. They
are listed and descibed below:

  bin\             contains several a launch scripts for the JCalendar
                   demo application for Windows XP/2000/NT/98.
  lib\             contains the software binaries (jar files)
                   for JCalendar and the Kunststoff Look & Feel.
  docs\api         contains JavaDoc documentation.
  src\             contains all the sources to make a distribution.
               

=======================================================================
Kunststoff

Kunststoff LnF (C) INCORS GmbH,
published under the GNU Lesser General Public License.

The official web site is:
	http://www.incors.com

=======================================================================
